import pandas as pd
import numpy as np
import networkx as nx
from networkx.algorithms.community import k_clique_communities
from   collections import defaultdict
import pickle


filename = 'M6I_R96H'
workdir = ''
cliquef = workdir + filename + "_all_atom.cli"
tmpnodef = workdir + filename + ".pdb_ringNodes"
tmpedgef = workdir + filename + ".pdb_ringEdges"
node = {}
edge = {}
node = pd.read_table(tmpnodef,encoding = 'latin-1')
edge = pd.read_table(tmpedgef,encoding = 'latin-1')
NodeSites = []
sites = {}
DistanceIndex = defaultdict(list)
EnergyIndex = defaultdict(list)
G = nx.Graph()
for i in edge.index:
    edges = edge.loc[i]
#    print(edges['NodeId1'].split(':')[1])
    site1 = int(edges['NodeId1'].split(':')[1])
    site2 = int(edges['NodeId2'].split(':')[1])
for i in edge.index:
    edges = edge.loc[i]
#    print(edges['NodeId1'].split(':')[1])
    site1 = int(edges['NodeId1'].split(':')[1])
    site2 = int(edges['NodeId2'].split(':')[1])
    if edges['Interaction'].split(':')[0] == 'HBOND': 
        if abs(site1-site2) > 4:
            index = str([site1,site2])
            DistanceIndex[index].append(edge.loc[i,'Distance'])
            EnergyIndex[index].append(edge.loc[i,'Energy'])
            sites[index] = (site1,site2)
            NodeSites.append(index)
    if edges['Interaction'].split(':')[0] == 'VDW':
        if abs(site1-site2) > 0.5:
            index = str([site1,site2])
            DistanceIndex[index].append(edge.loc[i,'Distance'])
            EnergyIndex[index].append(edge.loc[i,'Energy'])
            sites[index] = (site1,site2)
            NodeSites.append(index)
    if edges['Interaction'].split(':')[0] == 'IONIC':
        if abs(site1-site2) > 4:
            index = str([site1,site2])
            DistanceIndex[index].append(edge.loc[i,'Distance'])
            EnergyIndex[index].append(edge.loc[i,'Energy'])
            sites[index] = (site1,site2)
            NodeSites.append(index)
    if edges['Interaction'].split(':')[0] == 'PIPISTACK':
        if abs(site1-site2) > 6:
            index = str([site1,site2])
            DistanceIndex[index].append(edge.loc[i,'Distance'])
            EnergyIndex[index].append(edge.loc[i,'Energy'])
            sites[index] = (site1,site2)
            NodeSites.append(index)
    else:
        index = str([site1,site2])
        DistanceIndex[index].append(edge.loc[i,'Distance'])
        EnergyIndex[index].append(edge.loc[i,'Energy'])
        sites[index] = (site1,site2)
        NodeSites.append(index)
for index in NodeSites:
    E = sum(EnergyIndex[index])
    site1 = sites[index][0]
    site2 = sites[index][1]
    G.add_edge(site1,site2,Weight = E)#
print(len(node['Position']))
print(int(node['Position'][len(node['Position'])-1]))
for i in range(1,int(node['Position'][len(node['Position'])-1])):
#    print(i)
    G.add_edge(i,i+1)
fcliw = open(cliquef,'wb')
clique = defaultdict(dict)
clique = list(k_clique_communities(G,3))
pickle.dump(clique,fcliw)
print(clique)
print(len(clique))
fcliw.close()
